
echo "updating aqua LUTS..."
update_luts -v aqua


echo "updating terra LUTS..."
update_luts -v terra


echo "updating seawifs LUTS..."
update_luts -v seawifs


echo "updating viirsn LUTS..."
update_luts -v npp

echo "updating viirsn LUTS..."
update_luts -v j1
