#! /usr/bin/env python

class map_coords():
	north = 0
	south = 0
	east = 0
	west = 0